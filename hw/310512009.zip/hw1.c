//ezra last edit in 20220410
#include <stdio.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <stdbool.h>
#include <unistd.h>
#include <math.h>
#include "asm-arm/arch-pxa/lib/creator_pxa270_lcd.h"

long decimal_to_7seghex(int n);
void led_setting(int n,int fd);
void seg_setting(int n,int fd); 

int state_flag=0;//0 main list,1 shop list,2 food list,3 food order,4 shipping,5 done
int show_same=0;
int shop_choose=1;
int item_choose=1;
int stop_screen=0;
int item_num[3][2]={{0,0},{0,0},{0,0}};
int final_item_num[2]={0,0};
const int distance[3]={3,5,8};
const char* shop[3]={"1. dessert shop\n","2. Beverage Shop\n","3. Diner\n"};
const int cost[3][2]={{60,80},{40,70},{120,50}};
const char* item[3][2]={{"1. cookie:60$\n","2. cake:80$\n"},{"1. tea:40$\n","2. boba:70$\n"},{"1. fried rice:120$\n","2. Egg-drop soup:50$\n"}};

int main()
{
    unsigned short key;
    int fd,ret,i,j,n,but;
    int total = 0;
    int left_distance = 0;
    //char exp[100] = {0};
    unsigned char index = 0; 
    char* postfix;
    lcd_write_info_t display;
    int value; 
    bool end = false;

    /* Open device /dev/lcd */
    if((fd =open("/dev/lcd",O_RDWR))< 0) 
    {
        printf("Open /dev/lcd faild.\n");
        exit(-1);
    }
    /* clear */
    ioctl(fd, LCD_IOCTL_CLEAR, NULL);
    total = 0;
    seg_setting(total,fd);
    printf("start\n");

    state_flag = 0;
    stop_screen = 0;
    /* start */
    while(1)
    {
        //display
        if(state_flag == 0 && show_same == 0 && stop_screen == 0){
            ioctl(fd, LCD_IOCTL_CLEAR, NULL);
            printf("state 0, main\n");
            display.Count = sprintf((char *) display.Msg, "1.shop list\n2.order\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            show_same = 1;
        }else if(state_flag == 1 && show_same == 0 && stop_screen == 0)
        {
            ioctl(fd, LCD_IOCTL_CLEAR, NULL);
            printf("state 1, select shop\n");
            display.Count = sprintf((char *) display.Msg, "choose 1~3\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            for(i=0;i<3;i++){
                display.Count = sprintf((char *) display.Msg, shop[i]);
                ioctl(fd, LCD_IOCTL_WRITE, &display);
            }
            show_same = 1;
        }else if(state_flag == 2 && show_same == 0 && stop_screen == 0)
        {
            ioctl(fd, LCD_IOCTL_CLEAR, NULL);
            printf("state 2, select item\n");
            display.Count = sprintf((char *) display.Msg, "your shop is\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            display.Count = sprintf((char *) display.Msg, shop[shop_choose-1]);
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            display.Count = sprintf((char *) display.Msg, "\nchoose 1~4\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            for(i=0;i<2;i++){
                display.Count = sprintf((char *) display.Msg, item[shop_choose-1][i]);
                ioctl(fd, LCD_IOCTL_WRITE, &display);
            }
            display.Count = sprintf((char *) display.Msg, "3.confirm\n4.cancel\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            show_same = 1;
        }else if(state_flag == 3 && show_same == 0 && stop_screen == 0)
        {
            ioctl(fd, LCD_IOCTL_CLEAR, NULL);
            printf("state 3, item order\n");
            display.Count = sprintf((char *) display.Msg, "selected item :\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            display.Count = sprintf((char *) display.Msg, item[shop_choose-1][item_choose-1]);
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            display.Count = sprintf((char *) display.Msg, "\nhow many\n  ");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            show_same = 1;
        }else if(state_flag == 4 && stop_screen == 0)
        {//shipping
            if(show_same == 0){
                ioctl(fd, LCD_IOCTL_CLEAR, NULL);
                printf("state 4, shipping\n");
                display.Count = sprintf((char *) display.Msg, "Please wait for few minutes...\n");
                ioctl(fd, LCD_IOCTL_WRITE, &display);
                show_same = 1;
            }
            printf("left distance: %d\n", left_distance);
            if(left_distance>0){
                led_setting(left_distance,fd);
                sleep(1);
                left_distance--;
            }else if(left_distance == 0){
                led_setting(left_distance,fd);
                state_flag = 5;
                show_same = 0;
            }
        }else if(state_flag == 5 && show_same == 0 && stop_screen == 0)
        {//done
            ioctl(fd, LCD_IOCTL_CLEAR, NULL);
            printf("state 5, done\n");
            display.Count = sprintf((char *) display.Msg, "please pick up your meal\n");
            ioctl(fd, LCD_IOCTL_WRITE, &display);
            stop_screen = 1;
            state_flag = 0;//initial
            for(i=0;i<3;i++){
                for(j=0;j<2;j++){
                    item_num[i][j]=0;
                }
            }
            for(i=0;i<2;i++)
                final_item_num[i]=0;
            total = 0;
            seg_setting(total,fd);
        }
        //ioctl(fd, LCD_IOCTL_WRITE, &display);
        
        ret = ioctl(fd, KEY_IOCTL_CHECK_EMTPY, &key);
        if(ret<0)
        {
            sleep(1);
            continue;
        }
        ret = ioctl(fd, KEY_IOCTL_GET_CHAR,&key);
        //input
        but = 0;
        switch(key & 0xff)
        {
            case '0':
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 3){
                    n=item_num[shop_choose-1][item_choose-1];
                    item_num[shop_choose-1][item_choose-1]=n*10+0;
                    display.Count = sprintf((char *) display.Msg, "%c", key & 0xff);
                    ioctl(fd, LCD_IOCTL_WRITE, &display);
                }
                break;
            case '1':
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 0){
                    ioctl(fd, LCD_IOCTL_CLEAR, NULL);
                    display.Count = sprintf((char *) display.Msg, "dessert shop:\n3km\nBeverage Shop:\n5km\nDiner:\n8km\n");
                    ioctl(fd, LCD_IOCTL_WRITE, &display);
                    stop_screen = 1;
                    show_same = 0;
                }else if(state_flag == 1){//choose shop 1
                    shop_choose = 1;
                    state_flag = 2;
                    show_same = 0;
                }else if(state_flag == 2){//choose item 1    
                    item_choose = 1;    
                    state_flag = 3;    
                    show_same = 0;    
                }else if(state_flag == 3){
                    n=item_num[shop_choose-1][item_choose-1];
                    item_num[shop_choose-1][item_choose-1]=n*10+1;
                    display.Count = sprintf((char *) display.Msg, "%c", key &   0xff);
                    ioctl(fd, LCD_IOCTL_WRITE, &display);
                }else{
                    display.Count = sprintf((char *) display.Msg, "%c", key & 0xff);
                    //exp[index++] = key & 0xff;
                }
                break;
            case '2':
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 0){//start order, do initial
                    state_flag = 1;
                    show_same = 0;
                }else if(state_flag == 1){//choose shop 2
                    shop_choose = 2;
                    state_flag = 2;
                    show_same = 0;
                }else if(state_flag == 2){//choose item 2
                    item_choose = 2;
                    state_flag = 3;
                    show_same = 0;
                }else if(state_flag == 3){
                    n=item_num[shop_choose-1][item_choose-1];  
                    item_num[shop_choose-1][item_choose-1]=n*10+2;  
                    display.Count = sprintf((char *) display.Msg, "2");
                    ioctl(fd, LCD_IOCTL_WRITE, &display);  
                }else{
                    display.Count = sprintf((char *) display.Msg, "%c", key &   0xff);
                    //exp[index++] = key & 0xff;
                }
                break;
            case '3':
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 1){//choose shop 3
                    shop_choose = 3;
                    state_flag = 2;
                    show_same = 0;
                }else if(state_flag == 2){//confirm all item order
                    total=cost[shop_choose-1][0]*final_item_num[0]+cost[shop_choose-1][1]*final_item_num[1];
                    printf("total is %d\n",total);
                    if(total == 0){
                        state_flag = 0;
                        show_same = 0;
                        for(i=0;i<3;i++){
                            for(j=0;j<2;j++){
                                item_num[i][j]=0;
                            }
                        }
                        for(i=0;i<2;i++)
                            final_item_num[i]=0;
                    }else{
                        state_flag = 4;
                        show_same = 0;
                        seg_setting(total,fd);
                        left_distance = distance[shop_choose-1];
                        led_setting(left_distance,fd);
                    }
                }else if(state_flag == 3){
                    n=item_num[shop_choose-1][item_choose-1];  
                    item_num[shop_choose-1][item_choose-1]=n*10+3;  
                    display.Count = sprintf((char *) display.Msg, "3");
                    ioctl(fd, LCD_IOCTL_WRITE, &display);  
                }else{
                    display.Count = sprintf((char *) display.Msg, "%c", key &   0xff);
                    //exp[index++] = key & 0xff;
                }
                break;
            case '4':
                if(stop_screen == 1){    
                    stop_screen = 0;    
                    break;    
                }    
                if(state_flag == 2){
                    //cancel, initial
                    show_same = 0;
                    state_flag = 0;
                    for(i=0;i<3;i++){
                        for(j=0;j<2;j++){
                            item_num[i][j]=0;
                        }
                    }
                    for(i=0;i<2;i++)
                        final_item_num[i]=0;
                }else if(state_flag == 3){    
                    n=item_num[shop_choose-1][item_choose-1];    
                    item_num[shop_choose-1][item_choose-1]=n*10+4;    
                    display.Count = sprintf((char *) display.Msg, "4"); 
                    ioctl(fd, LCD_IOCTL_WRITE, &display);
                }                                            
                break;
            case '5':
                if(but == 0)
                    but=5;
            case '6':
                if(but == 0)
                    but=6;
            case '7':
                if(but == 0)
                    but=7;
            case '8':
                if(but == 0)
                    but=8;
            case '9':
                if(but == 0)
                    but=9;
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 3){
                    n=item_num[shop_choose-1][item_choose-1];
                    item_num[shop_choose-1][item_choose-1]=n*10+but;
                    display.Count = sprintf((char *) display.Msg, "%d",but);
                    ioctl(fd, LCD_IOCTL_WRITE, &display);
                }
                break;
            case '#':
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                if(state_flag == 3){
                    state_flag = 2;//back to item selection
                    show_same = 0;
                    final_item_num[item_choose-1]+=item_num[shop_choose-1][item_choose-1];
                    printf("%d\n", final_item_num[item_choose-1]);
                    item_num[shop_choose-1][item_choose-1]=0;
                }
                break;
            default:
                if(stop_screen == 1){
                    stop_screen = 0;
                    break;
                }
                break;
        }
        //ioctl(fd, LCD_IOCTL_WRITE, &display);
    }

    /* close fd */
    close(fd);
}

/* setting 7_seg and show number n*/
void seg_setting(int n, int fd)
{
    _7seg_info_t data_seg;

    ioctl(fd, _7SEG_IOCTL_ON, NULL);
    data_seg.Mode = _7SEG_MODE_HEX_VALUE;
    data_seg.Which = _7SEG_ALL;
    data_seg.Value = 0x0000+decimal_to_7seghex(n);
    ioctl(fd, _7SEG_IOCTL_SET, &data_seg);
}

void led_setting(int n, int fd)
{
    int i=0;
    unsigned short data;
    int Led_control = 0;

    /* Turn off all LED lamps */
    data = LED_ALL_OFF;
    ioctl(fd, LED_IOCTL_SET, &data);

    for(i;i<n;i++)
    {
        data = Led_control+i;
        ioctl(fd, LED_IOCTL_BIT_SET, &data);
    }
}

/* convert decimanl to 7seg value */
long decimal_to_7seghex(int n)
{
    char i = 0;
    unsigned long output = 0;

    while(n != 0)
    {
        output += n % 10 * pow(16,i);
        n /= 10;
        i ++; 
    }
    return output;
}

