//ezra last edit in 20220526

#include<arpa/inet.h>
#include<errno.h>
#include<netdb.h>
#include<netinet/in.h>
#include<signal.h> 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<unistd.h> 
#include <ctype.h>
#include<stdbool.h>
#include <sys/sem.h>
#include<time.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/mman.h>
#include "socket_utils.h"

#define BUFSIZE 1024
#define SEM_MODE 0666
long int *glob_var;

void Handler(int signum);
volatile int stop = 0;
const int cost[3][2]={{60,80},{40,70},{120,50}};
const char* shoplist="Dessert Shop:3km\n- cookie:60$|cake:80$\nBeverage Shop:5km\n- tea:40$|boba:70$\nDiner:8km\n- fried-rice:120$|Egg-drop-soup:50$";
const char* item[3][2]={{"cookie","cake"},{"tea","boba"},{"fried-rice","Egg-drop-soup"}};


int main(int argc, char* argv[])
{
    char *filename = "result.txt";
    int sockfd, connfd, yes = 1;
    char rcv[BUFSIZE], snd[BUFSIZE];
    int n, num, i=0, j=0;
    int pay=0;
    int shop_choose=-1;
    int item_num[2]={0,0};
    char *token, *item_s;
    int distance[3]={3,5,8};

    //time part 
    time_t seconds;
    
    //socket
    struct sockaddr_in cln;
    socklen_t cln_len = sizeof(cln);

    pid_t child_pid;
    if(argc!= 2){
        printf("Usage:_%s_port\n", argv[0]);
        exit(-1);
    }
    
    sockfd = createServerSock(atoi(argv[1]), TRANSPORT_TYPE_TCP);
    if(sockfd < 0)
    {
        printf("Can't_create_socket:\n");
        exit(-1);
    }

    signal(SIGINT, Handler);
    //semaphore part
    sem_t *sema = mmap(NULL, sizeof(*sema), 
      PROT_READ |PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,
      -1, 0);
    if(sema == MAP_FAILED){
        perror("mmap");
        exit(EXIT_FAILURE);
    }

    /* create/initialize semaphore */
    if(sem_init(sema, 1, 2) < 0){
        perror("sem_init");
        exit(EXIT_FAILURE);
    }


    //shared memory for record process
    glob_var = mmap(NULL, 4*sizeof (*glob_var), PROT_READ | PROT_WRITE, 
                    MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    glob_var[0] = 0;//deliver man 1
    glob_var[1] = 0;//deliver man 2
    glob_var[2] = 0;//total served customer
    glob_var[3] = 0;//total earned money


    //mutex part 
    pthread_mutex_t mutex;
    pthread_mutex_init(&mutex, NULL);
    
    // int process_idx = -1;
    while(!stop)
    {
        // process_idx += 1;
        connfd = accept(sockfd, ( struct sockaddr *) &cln, &cln_len);
        child_pid = fork();
        if(child_pid >= 0)
        {
            if(child_pid == 0)
            {
                
                while(1)
                {
                    if(connfd == -1)
                    {
                        printf("Error:_accept()\n");
                        exit(-1);
                    }
                    memset(rcv,'\0',sizeof(rcv));
                    while(1){
                        if((n = read(connfd, rcv, BUFSIZE)) == -1){
                            printf("Error: read()\n");
                            exit(-1);
                        }
                        if(strcmp(rcv,"")!=0){
                            break;
                        }
                    }
                    //printf("rcv: %s\n", rcv);
                    if(strcmp(rcv,"shop list") == 0){
			    n = sprintf(snd, "%s%c", shoplist, '\0');
		    }else if(strcmp(rcv,"confirm") == 0){
			    //confirm
			    if(shop_choose == -1){
				    n = sprintf(snd, "Please order some meals%c", '\0');
			    }else{
				    //////////////////
				    //wait time part
				    int wait = 0;
				    int start_time = 0;
				    int sema_idx = 0;
				    seconds = time(NULL);
				    //////////////////
				    //critical part for mutex
				    pthread_mutex_lock(&mutex);
				    //set glob_var for first time
				    if(glob_var[0] == 0)
				    {
					    glob_var[0] = seconds;                                       
					    sema_idx = 0;
				    }
 				    else if(glob_var[1] == 0)
  				    {
     					    glob_var[1] = seconds;
     					    sema_idx = 1;
 				    }
 				    else if(glob_var[0] <= glob_var[1])
 				    {
     					    wait = glob_var[0] - seconds;
     					    sema_idx = 0;
 				    }
  				    else
 				    {
     					    wait = glob_var[1] - seconds;
     					    sema_idx = 1;
 				    }
 				    start_time = glob_var[sema_idx];
 				    //order's arrive time for guests
				    glob_var[sema_idx] += distance[shop_choose];
				    wait += distance[shop_choose];
				    pay = item_num[0]*cost[shop_choose][0]+item_num[1]*cost[shop_choose][1];
                                   
 				    if(wait > 30)
  				    {
     					    memset(snd,'\0',sizeof(snd));
     					    n = sprintf(snd, "Your delivery will take a long time, do you want to wait?%c", '\0');
     					    if((n = write(connfd, snd, n)) == -1){
	 					    printf("Error: write()\n");
	 					    exit(-1);
     					    }
					    memset(snd,'\0',sizeof(snd));
     					    memset(rcv,'\0',sizeof(rcv));
     					    while(1){
	 					    if((n = read(connfd, rcv, BUFSIZE)) == -1){
	     						    printf("Error: read()\n");
	     						    exit(-1);
	 					    }
	 					    if(strcmp(rcv,"")!=0){
	     						    break;
	 					    }
     					    }
     					    if(strcmp(rcv, "No")==0)
     					    {
                                               glob_var[sema_idx] -= distance[shop_choose];
   					       pthread_mutex_unlock(&mutex);
   					       break;
					    }
					    memset(snd,'\0',sizeof(snd));
				    }
				    pthread_mutex_unlock(&mutex);
				    //end of critical part for mutex
				    //end of wait time part
				    /////////////////////

				    while(1)
				    {
     					    seconds = time(NULL);
     					    if(seconds >= start_time)
     					    {
	 					    break;
     					    }
 				    }
 				    sem_wait(sema);
 				    if(wait < 30)
 				    {
     					    memset(snd,'\0',sizeof(snd));
     					    n = sprintf(snd, "Please wait a few minutes...%c", '\0');
     					    if((n = write(connfd, snd, n)) == -1){
	 					    printf("Error: write()\n");
	 					    exit(-1);
     					    }
 				    }
 				    sleep(distance[shop_choose]);
 				    memset(snd,'\0',sizeof(snd));
 				    n = sprintf(snd, "Delivery has arrived and you need to pay %d$%c", pay,'\0');
 				    if((n = write(connfd, snd, n)) == -1){
     					    printf("Error: write()\n");
     					    exit(-1);
 				    }
				    shop_choose = -1;
		    		    item_num[0] = 0;
		    		    item_num[1] = 0;
                                   
				    seconds = time(NULL);
 				    sem_post(sema);
                                   
 				    pthread_mutex_lock(&mutex);
 				    //open txt file part
				    FILE *fp = fopen(filename, "w");
				    glob_var[2] ++;
				    glob_var[3] += pay;
 				    memset(snd,'\0',sizeof(snd));
 				    n = sprintf(snd, "customer: %ld, income: %ld\n", glob_var[2], glob_var[3]);
 				    fputs(snd,fp);
 				    fclose(fp);
 				    pthread_mutex_unlock(&mutex);
 				    printf("confirm: %d\n", pay);
 				    break;
			    }
		    }else if(strcmp(rcv,"cancel") == 0){
			    //cancel
			    pay=0;
			    shop_choose = -1;
			    item_num[0] = 0;
			    item_num[1] = 0;
			    memset(snd,'\0',sizeof(snd));
		    }else{
			    //get order information
			    token = strtok(rcv, " ");
			    if(strcmp(token,"order") != 0)
				    continue;
			    token = strtok(NULL, " ");
			    item_s = token;
			    token = strtok(NULL, " ");
			    sscanf(token, "%d", &num);
			    //see what shop is
			    for(i=0;i<3;i++){
		    		    for(j=0;j<2;j++){
					    if(strcmp(item_s,item[i][j]) == 0){
			    			    if(shop_choose == -1){
							    shop_choose=i;
							    item_num[j]+=num;
			    			    }else if(shop_choose != i){
							    //do nothing
						    }else{
							    //order
							    item_num[j]+=num;
			    			    }
					    }
		    		    }
			    }
			    //need to check if two item or one
			    if(item_num[0]!=0 && item_num[1]!=0){
				    n = sprintf(snd, "%s %d|%s %d%c", item[shop_choose][0], item_num[0],item[shop_choose][1], item_num[1], '\0');
			    }else if(item_num[0]!=0){
				    n = sprintf(snd, "%s %d%c", item[shop_choose][0], item_num[0], '\0');
			    }else if(item_num[1]!=0){
				    n = sprintf(snd, "%s %d%c", item[shop_choose][1], item_num[1], '\0');
			    }else{
				    //no item
			    }
		    }
		    if((n = write(connfd,snd, n)) == -1){
			    printf("Error: write()\n");
		    }	    
		    memset(snd,'\0',sizeof(snd));
		}
                close(connfd);
                exit(0);
            }
            
        }
    }
    close(connfd);
    close(sockfd);
    
    return 0;
}

void Handler(int signum)
{
    stop = 1;
    while(waitpid(-1, NULL, WNOHANG) > 0);
    exit(0);
}
