#!/bin/sh

set -x
# set -e

rmmod -f mydev
insmod mydev.ko

./writer chenyi &
./reader 192.168.0.77 8877 /dev/mydev
