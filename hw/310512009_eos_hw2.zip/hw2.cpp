//ezra last edit in 20220505
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include "socket_utils.h"
#include <semaphore.h>
#include <vector>
#include <algorithm>
#include <cstdint>
#define BUFSIZE 1024
using namespace std;

//int distance[3]={3,5,8};    
//const char* shop[3]={"Dessert Shop:3km\n","Beverage Shop:5km\n","Diner:8km\n"};   
const int cost[3][2]={{60,80},{40,70},{120,50}};
const char* shoplist="Dessert Shop:3km\n- cookie:60$|cake:80$\nBeverage Shop:5km\n- tea:40$|boba:70$\nDiner:8km\n- fried-rice:120$|Egg-drop-soup:50$";
const char* item[3][2]={{"cookie","cake"},{"tea","boba"},{"fried-rice","Egg-drop-soup"}};
char snd[BUFSIZE];
void *process(void *t);

int main(int argc, char *argv[])
{    
    int sockfd, connfd;
    struct sockaddr_in cln;
    socklen_t cln_len = sizeof(cln);

    int pth_c;
    pthread_t threadd,thr;
    int t=0;
    
    if(argc != 2){
        printf("Usasge: %s port\n", argv[0]);
    }

    //while(1){
    //sockfd = passivesock(argv[1], "tcp", 10);
    sockfd = createServerSock(atoi(argv[1]), TRANSPORT_TYPE_TCP);
    if(sockfd<0){
        printf("Error create socket\n");
        exit(-1);
    }

    while(1)
    {
        connfd = accept(sockfd, ( struct sockaddr *) &cln, &cln_len);
        if(connfd == -1){
            printf("Error: accept()");
            continue;
        }
        pth_c = pthread_create(&threadd, NULL, process, (void *)connfd);
        
        if(pth_c)
        {
            printf("ERROR return code from pthread_create( ) is %d\n", pth_c);
            exit(-1);
        }
    }
    close(sockfd);
    //}
    return 0;
}

void *process(void *t)
{
    /* initial */
    //char snd[BUFSIZE];
    char rcv[BUFSIZE];
    int n,num,i,j;
    bool con =false;
    int connfd=(intptr_t)t;
    int shop_choose=-1, total=0;
    int item_num[2]={0,0};
    char *token, *item_s;
    int distance[3]={3,5,8};
    /* start */
    total=0;
    shop_choose=-1;
    item_num[0]=0;
    item_num[1]=0;


    //printf("start\n");
    while(1)
    {
        memset(rcv,'\0',sizeof(rcv));
        //memset(snd,'\0',sizeof(snd));
        
        while(1){
            //printf("try to recieve\n");
            if((n = read(connfd, rcv, BUFSIZE)) == -1){
                printf("Error: read()\n");
            }
            //printf("recieved\n");
            if(strcmp(rcv,"") != 0){
                break;
            }
        }

        if(strcmp(rcv,"shop list") == 0){
            n = sprintf(snd, "%s%c", shoplist, '\0');
        }else if(strcmp(rcv,"confirm") == 0){
            //confirm
            if(shop_choose == -1){
                n = sprintf(snd, "Please order some meals%c", '\0');
            }else{
                n = sprintf(snd, "Please wait a few minutes...%c", '\0');
                //printf("%s\n",snd);
                if((n = write(connfd,snd, n)) == -1){
                    printf("Error: write()\n");
                }
                memset(snd,'\0',sizeof(snd));
                total=item_num[0]*cost[shop_choose][0]+item_num[1]*cost[shop_choose][1];
                sleep(distance[shop_choose]);
                //sleep(3);
                n = sprintf(snd, "Delivery has arrived and you need to pay %d$%c", total,'\0');
                total=0;
                shop_choose = -1;
                item_num[0] = 0;
                item_num[1] = 0;
                //memset(snd,'\0',sizeof(snd));
            }
        }else if(strcmp(rcv,"cancel") == 0){
            //cancel
            total=0;
            shop_choose = -1;
            item_num[0] = 0;
            item_num[1] = 0;
            memset(snd,'\0',sizeof(snd));
        }else{
            //get order information
            token = strtok(rcv, " ");
            if(strcmp(token,"order") != 0)
                continue;
            token = strtok(NULL, " ");
            item_s = token;
            token = strtok(NULL, " ");
            sscanf(token, "%d", &num);
            //see what shop is
            for(i=0;i<3;i++){
                for(j=0;j<2;j++){
                    if(strcmp(item_s,item[i][j]) == 0){
                        if(shop_choose == -1){
                            shop_choose=i;
                            item_num[j]+=num;
                        }else if(shop_choose != i){
                            //do nothing
                        }else{
                            //order
                            item_num[j]+=num;
                        }
                    }
                }
            }
            //need to check if two item or one
            if(item_num[0]!=0 && item_num[1]!=0){
                n = sprintf(snd, "%s %d|%s %d%c", item[shop_choose][0], item_num[0],item[shop_choose][1], item_num[1], '\0');
            }else if(item_num[0]!=0){
                n = sprintf(snd, "%s %d%c", item[shop_choose][0], item_num[0], '\0');
            }else if(item_num[1]!=0){
                n = sprintf(snd, "%s %d%c", item[shop_choose][1], item_num[1], '\0');
            }else{
                //no item
            }
        }

        //printf("%s\n",snd);
        if((n = write(connfd,snd, n)) == -1){
            printf("Error: write()\n");
        }
        memset(snd,'\0',sizeof(snd));
    }
    //printf("end\n");
    close(connfd);
    pthread_exit(NULL);
}
